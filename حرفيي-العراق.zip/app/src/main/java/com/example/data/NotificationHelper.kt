package com.example.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity

object NotificationHelper {
    const val CHANNEL_CHAT_ID = "iraqi_crafts_chats"
    const val CHANNEL_REVIEWS_ID = "iraqi_crafts_reviews"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nameChat = "محادثات الحرفيين (الرسائل)"
            val descriptionTextChat = "تنبيهات فورية عند استلام رسائل عمل جديدة من الزبائن"
            val importanceChat = NotificationManager.IMPORTANCE_HIGH
            val channelChat = NotificationChannel(CHANNEL_CHAT_ID, nameChat, importanceChat).apply {
                description = descriptionTextChat
                enableVibration(true)
            }

            val nameReviews = "تقييمات وآراء الزبائن"
            val descriptionTextReviews = "إشعارات بالتقييمات الجديدة ومستويات الرضا حول الخدمة الموفرة"
            val importanceReviews = NotificationManager.IMPORTANCE_DEFAULT
            val channelReviews = NotificationChannel(CHANNEL_REVIEWS_ID, nameReviews, importanceReviews).apply {
                description = descriptionTextReviews
            }

            // Register the channels with the system
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channelChat)
            notificationManager.createNotificationChannel(channelReviews)
            Log.d("NotificationHelper", "Notification Channels registered successfully.")
        }
    }

    fun showSystemNotification(
        context: Context,
        title: String,
        message: String,
        isChat: Boolean = true
    ) {
        try {
            val channelId = if (isChat) CHANNEL_CHAT_ID else CHANNEL_REVIEWS_ID
            val notificationId = if (isChat) 1001 + (0..999).random() else 2001 + (0..999).random()

            // Open MainActivity on tap
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.stat_notify_chat) // Standard platform notification icon
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(if (isChat) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setCategory(if (isChat) NotificationCompat.CATEGORY_MESSAGE else NotificationCompat.CATEGORY_RECOMMENDATION)

            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            notificationManager.notify(notificationId, builder.build())
            Log.d("NotificationHelper", "System notification displayed: $title - $message")
        } catch (e: Exception) {
            Log.e("NotificationHelper", "Error showing notification", e)
        }
    }
}
