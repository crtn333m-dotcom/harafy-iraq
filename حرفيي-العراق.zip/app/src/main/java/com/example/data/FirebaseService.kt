package com.example.data

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow

object FirebaseService {
    var isInitialized = false
        private set

    val firebaseConfigState = MutableStateFlow<String>("بانتظار تهيئة المشروع (يرجى إدخال ملف الإعدادات أو المفاتيح)")
    val syncStatus = MutableStateFlow<String>("جاهز للمزامنة مع Firestore")

    fun initializeDynamically(
        context: Context,
        apiKey: String,
        projectId: String,
        applicationId: String
    ): Boolean {
        return try {
            val options = FirebaseOptions.Builder()
                .setApiKey(apiKey)
                .setProjectId(projectId)
                .setApplicationId(applicationId)
                .build()

            // If Firebase is already initialized, we don't crash, we just note it or work with current app
            val apps = FirebaseApp.getApps(context)
            if (apps.isEmpty()) {
                FirebaseApp.initializeApp(context, options)
            } else {
                // Secondary app or recreate if needed. The API lets us fetch the default or register dynamic options.
                // We'll safely reinitialize or log.
                Log.d("FirebaseService", "Firebase App has already been initialized.")
            }
            
            isInitialized = true
            firebaseConfigState.value = "متصل بنجاح بمشروع Firebase: $projectId"
            true
        } catch (e: Exception) {
            Log.e("FirebaseService", "Initialization error", e)
            firebaseConfigState.value = "خطأ في الربط: ${e.localizedMessage}"
            false
        }
    }

    fun safetyInitialize(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                isInitialized = true
                firebaseConfigState.value = "صلة الربط بـ Firebase نشطة ومبرمجة تلقائياً"
                return
            }
            FirebaseApp.initializeApp(context)
            isInitialized = true
            firebaseConfigState.value = "متصل تلقائياً بمشروع Firebase الافتراضي"
        } catch (e: Exception) {
            Log.w("FirebaseService", "Default google-services.json not found. Awaiting dynamic or custom configuration.")
            firebaseConfigState.value = "لم يتم الكشف عن ملف google-services.json. يمكنك استخدام التهيئة اليدوية أدناه للربط الفوري بمشروعك الذاتي."
        }
    }
    
    // Firestore synchronizer to push local Room database documents to Firestore
    fun syncDataToFirestore(
        craftsmen: List<Craftsman>,
        reviews: List<Review>,
        professions: List<Profession>,
        onComplete: (Boolean, String) -> Unit
    ) {
        if (!isInitialized) {
            onComplete(false, "عذراً، يرجى ملء مفاتيح الاتصال أو إضافة ملف google-services.json لربط التطبيق بـ Firebase أولاً.")
            return
        }
        try {
            val db = FirebaseFirestore.getInstance()
            
            // Push Professions to Firestore
            professions.forEach { prof ->
                db.collection("professions")
                    .document(prof.id.toString())
                    .set(mapOf(
                        "id" to prof.id, 
                        "name" to prof.name, 
                        "iconName" to prof.iconName
                    ))
            }

            // Push Craftsmen to Firestore
            craftsmen.forEach { craftsman ->
                db.collection("craftsmen")
                    .document(craftsman.id.toString())
                    .set(
                        mapOf(
                            "id" to craftsman.id,
                            "name" to craftsman.name,
                            "profession" to craftsman.profession,
                            "bio" to craftsman.bio,
                            "phone" to craftsman.phone,
                            "avatarUrl" to craftsman.avatarUrl,
                            "isVerified" to craftsman.isVerified,
                            "isBlocked" to craftsman.isBlocked,
                            "overallRating" to craftsman.overallRating,
                            "reviewCount" to craftsman.reviewCount
                        )
                    )
            }

            // Push Reviews to Firestore
            reviews.forEach { r ->
                db.collection("reviews")
                    .document(r.id.toString())
                    .set(
                        mapOf(
                            "id" to r.id,
                            "customerId" to r.customerId,
                            "craftsmanId" to r.craftsmanId,
                            "customerName" to r.customerName,
                            "rating" to r.rating,
                            "comment" to r.comment,
                            "timestamp" to r.timestamp,
                            "status" to r.status
                        )
                    )
            }

            onComplete(true, "✅ تمت المزامنة الفورية! تم ترحيل وبيك اب (${craftsmen.size} حرفي، ${reviews.size} تقييم، و ${professions.size} تخصص) بنجاح إلى Firestore!")
        } catch (e: Exception) {
            onComplete(false, "فشل الاتصال: ${e.localizedMessage}. تأكد من صلاحيات وقواعد الحماية (Security Rules) في Firestore.")
        }
    }

    // Auth simulation & actual integration hooks for users setup
    fun createFirebaseUser(phone: String, isCraftsman: Boolean, onComplete: (Boolean, String) -> Unit) {
        if (!isInitialized) {
            onComplete(false, "شريط التوثيق غير متصل بـ Firebase. يرجى تهيئة الاتصال أولاً.")
            return
        }
        try {
            val auth = FirebaseAuth.getInstance()
            // Firebase Auth phone authentication or custom token registration template
            val emailMock = "${phone}@iraqicrafts.com"
            val passwordMock = "1234567" // Default temporary setup passcode
            
            auth.createUserWithEmailAndPassword(emailMock, passwordMock)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        onComplete(true, "تم إنشاء وتوثيق مستخدم جديد بنجاح في Firebase Auth! المعرف: ${task.result?.user?.uid}")
                    } else {
                        onComplete(false, "تعذر التسجيل التلقائي: ${task.exception?.localizedMessage}")
                    }
                }
        } catch (e: Exception) {
            onComplete(false, "خطأ بالاتصال بـ Auth: ${e.localizedMessage}")
        }
    }
}
