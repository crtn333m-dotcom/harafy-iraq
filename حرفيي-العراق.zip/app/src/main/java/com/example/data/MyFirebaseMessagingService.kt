package com.example.data

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCMService", "FCM Device Token refreshed: $token")
        // In real cases we would update this token in FireStore for the targeted craftsman or customer
        FirebaseService.syncStatus.value = "تم تجديد رمز جهاز الإشعارات الفورية: ${token.take(12)}..."
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d("FCMService", "FCM notification payload received: ${remoteMessage.data}")

        // Decode push payload values
        val title = remoteMessage.notification?.title ?: remoteMessage.data["title"] ?: "تنبيه جديد"
        val body = remoteMessage.notification?.body ?: remoteMessage.data["body"] ?: "وصلتك رسالة جديدة من تطبيق حرفيي العراق"
        val type = remoteMessage.data["type"] ?: "chat" // e.g. "chat" or "review"
        
        // Push notification immediately to status bar
        NotificationHelper.showSystemNotification(
            context = applicationContext,
            title = title,
            message = body,
            isChat = (type == "chat")
        )
    }
}
