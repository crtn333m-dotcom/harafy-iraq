package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

@Dao
interface AppDao {
    // Craftsmen
    @Query("SELECT * FROM craftsmen ORDER BY isVerified DESC, name ASC")
    fun getAllCraftsmen(): Flow<List<Craftsman>>

    @Query("SELECT * FROM craftsmen WHERE id = :id")
    fun getCraftsmanById(id: Int): Flow<Craftsman?>

    @Query("SELECT * FROM craftsmen WHERE id = :id")
    suspend fun getCraftsmanByIdSync(id: Int): Craftsman?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCraftsman(craftsman: Craftsman)

    @Update
    suspend fun updateCraftsman(craftsman: Craftsman)

    @Query("DELETE FROM craftsmen WHERE id = :id")
    suspend fun deleteCraftsmanById(id: Int)

    // Reviews
    @Query("SELECT * FROM reviews WHERE status = 'APPROVED' ORDER BY timestamp DESC")
    fun getAllApprovedReviews(): Flow<List<Review>>

    @Query("SELECT * FROM reviews ORDER BY timestamp DESC")
    fun getAllReviews(): Flow<List<Review>>

    @Query("SELECT * FROM reviews WHERE craftsmanId = :craftsmanId AND status = 'APPROVED' ORDER BY timestamp DESC")
    fun getReviewsForCraftsman(craftsmanId: Int): Flow<List<Review>>

    @Query("SELECT * FROM reviews WHERE craftsmanId = :craftsmanId AND status = 'APPROVED'")
    suspend fun getReviewsForCraftsmanSync(craftsmanId: Int): List<Review>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: Review)

    @Update
    suspend fun updateReview(review: Review)

    @Query("UPDATE reviews SET status = 'DELETED' WHERE id = :id")
    suspend fun softDeleteReview(id: Int)

    @Query("DELETE FROM reviews WHERE id = :id")
    suspend fun deleteReviewById(id: Int)

    // Professions
    @Query("SELECT * FROM professions ORDER BY name ASC")
    fun getAllProfessions(): Flow<List<Profession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfession(profession: Profession)

    @Query("DELETE FROM professions WHERE id = :id")
    suspend fun deleteProfessionById(id: Int)

    // AdBanners
    @Query("SELECT * FROM ad_banners ORDER BY id DESC")
    fun getAllAdBanners(): Flow<List<AdBanner>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdBanner(adBanner: AdBanner)

    @Query("DELETE FROM ad_banners WHERE id = :id")
    suspend fun deleteAdBannerById(id: Int)

    // ChatMessages
    @Query("SELECT * FROM chat_messages WHERE craftsmanId = :craftsmanId ORDER BY timestamp ASC")
    fun getChatMessages(craftsmanId: Int): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessage)

    @Query("DELETE FROM chat_messages WHERE craftsmanId = :craftsmanId")
    suspend fun clearChat(craftsmanId: Int)

    // AppSettings
    @Query("SELECT * FROM app_settings WHERE id = 1")
    fun getAppSettingsFlow(): Flow<AppSettings?>

    @Query("SELECT * FROM app_settings WHERE id = 1")
    suspend fun getAppSettingsSync(): AppSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppSettings(settings: AppSettings)
}

@Database(
    entities = [
        Craftsman::class,
        Review::class,
        Profession::class,
        AdBanner::class,
        ChatMessage::class,
        AppSettings::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract val dao: AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "iraqi_craftsmen_db"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.dao)
                }
            }
        }

        private suspend fun populateDatabase(dao: AppDao) {
            // Seed Settings
            dao.insertAppSettings(
                AppSettings(
                    id = 1,
                    managerPhone = "07740400741",
                    managerPassword = "19851985",
                    welcomeText = "مرحباً بكم في منصة 'حرفيي العراق' المجانية! نربط بين الحرفيين المهرة وعملائهم بكل أمان ومصداقية. جميع الحقوق محفوظة لـ حسين الدخيل.",
                    primaryColorHex = "#2E7D32", // Traditional Palm green
                    backgroundColorHex = "#FAF9F6" // Standard creamy requested background
                )
            )

            // Seed Professions (المهن)
            val professions = listOf(
                Profession(name = "كهربائي خانات ومنازل", iconName = "electrician"),
                Profession(name = "سباكة وأعمال صحية", iconName = "plumbing"),
                Profession(name = "نجار أثاث وديكور", iconName = "carpenter"),
                Profession(name = "بناء ومقاولات عامة", iconName = "builder"),
                Profession(name = "حدادة أبواب وشبابيك", iconName = "blacksmith"),
                Profession(name = "أعمال الصبغ والطلاء", iconName = "painter"),
                Profession(name = "تصليح أجهزة تبريد ومكيفات", iconName = "cooling")
            )
            professions.forEach { dao.insertProfession(it) }

            // Seed Ad Banners (إعلانات الإدارة)
            val banners = listOf(
                AdBanner(
                    text = "🚨 هام: منصة حرفيي العراق مجانية بالكامل. لا تدفع أي مبالغ للمنصة، تواصل مباشرة مع الحرفيين مجاناً!",
                    linkUrl = "https://example.com/free"
                ),
                AdBanner(
                    text = "🌟 ميزة جديدة: يمكنك الآن طلب شارة التوثيق (✓) عن طريق لوحة المحادثة مع الإدارة بعد تزويد المستمسكات الرسمية.",
                    linkUrl = "https://example.com/verify"
                ),
                AdBanner(
                    text = "🛠️ هل أنت حرفي ماهر في بغداد أو المحافظات؟ سجل الآن مجاناً ووسّع شبكة أعمالك ووفر دخلاً إضافياً ممتازاً!",
                    linkUrl = "https://example.com/apply"
                )
            )
            banners.forEach { dao.insertAdBanner(it) }

            // Seed Craftsmen (الحرفيين)
            val c1 = Craftsman(
                name = "أبو علي الخفاجي",
                profession = "سباكة وأعمال صحية",
                bio = "خبرة أكثر من ١٥ سنة في تمديد شبكات المياه والمجاري وتصليح جميع أنواع المضخات والفلاتر في بغداد. دقة وسرعة في العمل وأسعار مناسبة جداً.",
                phone = "07712345678",
                avatarUrl = "avatar_1",
                portfolioImagesStr = "p_plumb_1;p_plumb_2;p_plumb_3",
                isVerified = true,
                overallRating = 4.8f,
                reviewCount = 5
            )

            val c2 = Craftsman(
                name = "كرار الكهربائي",
                profession = "كهربائي خانات ومنازل",
                bio = "متخصص في تأسيس خطوط الكهرباء الحديثة للبيوت والمحلات وتصليح البوردات والسبلت الكهربائي. خدمة سريعة متوفرة على مدار ٢٤ ساعة في الكرخ والرصافة.",
                phone = "07801234567",
                avatarUrl = "avatar_2",
                portfolioImagesStr = "p_elec_1;p_elec_2",
                isVerified = true,
                overallRating = 4.9f,
                reviewCount = 4
            )

            val c3 = Craftsman(
                name = "أبو وسام النجار",
                profession = "نجار أثاث وديكور",
                bio = "نجارة الموديلات التركية والعراقية، تصليح غرف النوم، تفصيل الكاونترات والدواليب، تصليح الأبواب والمطابخ بأسعار ممتازة وخامات عالية الجودة.",
                phone = "07901112223",
                avatarUrl = "avatar_3",
                portfolioImagesStr = "p_carp_1;p_carp_2",
                isVerified = false,
                overallRating = 4.2f,
                reviewCount = 3
            )

            val c4 = Craftsman(
                name = "عادل الصباغ",
                profession = "أعمال الصبغ والطلاء",
                bio = "صبغ بيوت داخلي وخارجي، ديكورات ورق جدران، صبغ بوب وخشب بأحدث المواد المضادة للرطوبة. ملتزمين بالوقت والنظافة.",
                phone = "07705556667",
                avatarUrl = "avatar_4",
                portfolioImagesStr = "p_paint_1",
                isVerified = false,
                overallRating = 4.5f,
                reviewCount = 2
            )

            dao.insertCraftsman(c1)
            dao.insertCraftsman(c2)
            dao.insertCraftsman(c3)
            dao.insertCraftsman(c4)

            // Seed Reviews (التقييمات والتعليقات الإجبارية)
            // Customer IDs are simulated names/uuids
            val reviews = listOf(
                Review(customerId = "c_user1", craftsmanId = 1, customerName = "أزهر السعيدي", rating = 5, comment = "عمل نظيف جداً وسريع، محترم وأهم شيء السعر مناسب وملتزم بالموعد. أنصح بالتعامل معه بشدة!"),
                Review(customerId = "c_user2", craftsmanId = 1, customerName = "أبو فهد الحلي", rating = 5, comment = "كفاءة عالية وأخلاق طيبة. أصلح كسر معقد بتكسير خفيف جداً. شكراً لمنصة حرفيي العراق."),
                Review(customerId = "c_user3", craftsmanId = 1, customerName = "سارة الجبوري", rating = 4, comment = "سباك ذكي وجاء بالموقت المناسب لتصليح البايبات الأساسية بالبيت. الف شكر."),
                Review(customerId = "c_user4", craftsmanId = 1, customerName = "أحمد الربيعي", rating = 5, comment = "رجل طيب وأمين ويده مباركة. تصليح ممتاز وتجربة مريحة جداً."),
                Review(customerId = "c_user5", craftsmanId = 1, customerName = "بهاء الطائي", rating = 5, comment = "شخص فاهم شغله وتعامله راقي جداً."),
                
                Review(customerId = "c_user6", craftsmanId = 2, customerName = "صفاء الحسيني", rating = 5, comment = "تأسيس كهرباء خيالي ومطابق للمواصفات. رتب البورد بشكل جميل جداً ويراعي شروط السلامة."),
                Review(customerId = "c_user7", craftsmanId = 2, customerName = "مصطفى الخفاجي", rating = 5, comment = "أفضل كهربائي تعاملت معه في بغداد. دقة وسرعة متناهية."),
                Review(customerId = "c_user8", craftsmanId = 2, customerName = "أم يوسف الكرخي", rating = 4, comment = "جاء بوقت متأخر جداً بالليل وحل مشكلة انقطاع الكهرباء العام بالبيت بسرعة. ربي يرزقه."),
                Review(customerId = "c_user9", craftsmanId = 2, customerName = "حسين الدخيل", rating = 5, comment = "شغل مخلص وضمير حي. ربي يحفظك ويكثر من أمثالك."),

                Review(customerId = "c_user10", craftsmanId = 3, customerName = "علي التميمي", rating = 4, comment = "نجار رائع عمل على تصليح كنتور مكسور وأرجعه كالجديد. السعر مقبول جداً."),
                Review(customerId = "c_user11", craftsmanId = 3, customerName = "محمد العبيدي", rating = 5, comment = "تفصيل كاونتر مطبخ عراقي غاية في الروعة والمتانة. بارك الله فيك."),
                Review(customerId = "c_user12", craftsmanId = 3, customerName = "بشير الكناني", rating = 3, comment = "العمل جيد وممتاز لكنه تأخر يومين عن الموعد المتفق عليه لغرفة النوم."),

                Review(customerId = "c_user13", craftsmanId = 4, customerName = "زهير الدفاعي", rating = 5, comment = "صبغ الصالة ممتاز جداً وألوانه دقيقة ومريحة والاهتمام بالتفاصيل عالي جداً."),
                Review(customerId = "c_user14", craftsmanId = 4, customerName = "رعد البابلي", rating = 4, comment = "معلم صبغ حقيقي ومرتب. نظافته بالعمل لا توصف.")
            )
            reviews.forEach { dao.insertReview(it) }

            // Seed Some Chat History (محادثات افتراضية مسبقة للتجربة)
            val chatHistory = listOf(
                ChatMessage(craftsmanId = 1, senderId = "customer", text = "السلام عليكم عيني أبو علي، محتاج تصليح خلاط مكسور في الحمام بالمنصور"),
                ChatMessage(craftsmanId = 1, senderId = "craftsman", text = "وعليكم السلام والرحمة غالي، تدلل. متى يناسبك أجي أشوفه؟"),
                ChatMessage(craftsmanId = 1, senderId = "customer", text = "إذا تكدر اليوم العصر حيكون ممتاز"),
                ChatMessage(craftsmanId = 1, senderId = "craftsman", text = "تمام عيني العصر ب٤ أكون عندك إن شاء الله. أرسلي لوكيشن بيتك"),
                ChatMessage(craftsmanId = 1, senderId = "customer", text = "هذا موقع البيت بالضبط عيني وتدلل", locationCoordinates = "33.3152,44.3661")
            )
            chatHistory.forEach { dao.insertChatMessage(it) }
        }
    }
}
