package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "craftsmen")
data class Craftsman(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val profession: String,
    val bio: String,
    val phone: String,
    val avatarUrl: String,
    val portfolioImagesStr: String = "", // Semicolon separated image names
    val isVerified: Boolean = false,
    val isBlocked: Boolean = false,
    val overallRating: Float = 0f,
    val reviewCount: Int = 0
)

@Entity(tableName = "reviews")
data class Review(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerId: String,
    val craftsmanId: Int,
    val customerName: String,
    val rating: Int, // 1-5
    val comment: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "APPROVED" // "APPROVED", "PENDING", "DELETED"
)

@Entity(tableName = "professions")
data class Profession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val iconName: String = "ic_default"
)

@Entity(tableName = "ad_banners")
data class AdBanner(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val linkUrl: String = "",
    val imageUrl: String = ""
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val craftsmanId: Int,
    val senderId: String, // "customer" or "craftsman"
    val text: String,
    val imageUrl: String? = null,
    val voiceDuration: Int = 0, // In seconds (0 meaning not a voice note)
    val locationCoordinates: String? = null, // "lat,lng" for map sharing
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val id: Int = 1,
    val managerPhone: String = "07701234567",
    val managerPassword: String = "12345",
    val welcomeText: String = "مرحباً بكم في تطبيق حرفيي العراق - المنصة المجانية لدعم الحرفيين",
    val primaryColorHex: String = "#008080", // Standard Teal Palm Green
    val backgroundColorHex: String = "#FAF9F6" // Warm Creamy
)
