package com.example.data

import kotlinx.coroutines.flow.Flow

class AppRepository(private val dao: AppDao) {

    // Craftsmen
    val allCraftsmen: Flow<List<Craftsman>> = dao.getAllCraftsmen()

    fun getCraftsmanById(id: Int): Flow<Craftsman?> = dao.getCraftsmanById(id)

    suspend fun insertCraftsman(craftsman: Craftsman) {
        dao.insertCraftsman(craftsman)
    }

    suspend fun updateCraftsman(craftsman: Craftsman) {
        dao.updateCraftsman(craftsman)
    }

    suspend fun deleteCraftsmanById(id: Int) {
        dao.deleteCraftsmanById(id)
    }

    // Reviews
    val allReviews: Flow<List<Review>> = dao.getAllReviews()
    val allApprovedReviews: Flow<List<Review>> = dao.getAllApprovedReviews()

    fun getReviewsForCraftsman(craftsmanId: Int): Flow<List<Review>> =
        dao.getReviewsForCraftsman(craftsmanId)

    suspend fun insertReview(review: Review) {
        dao.insertReview(review)
        recalculateCraftsmanRating(review.craftsmanId)
    }

    suspend fun updateReview(review: Review) {
        dao.updateReview(review)
        recalculateCraftsmanRating(review.craftsmanId)
    }

    suspend fun softDeleteReview(id: Int, craftsmanId: Int) {
        dao.softDeleteReview(id)
        recalculateCraftsmanRating(craftsmanId)
    }

    suspend fun deleteReviewById(id: Int, craftsmanId: Int) {
        dao.deleteReviewById(id)
        recalculateCraftsmanRating(craftsmanId)
    }

    // Recalculates average rating and total counts
    suspend fun recalculateCraftsmanRating(craftsmanId: Int) {
        val reviews = dao.getReviewsForCraftsmanSync(craftsmanId)
        val approvedReviews = reviews.filter { it.status == "APPROVED" }
        val count = approvedReviews.size
        val average = if (count > 0) {
            approvedReviews.map { it.rating }.average().toFloat()
        } else {
            0f
        }
        val craftsman = dao.getCraftsmanByIdSync(craftsmanId)
        if (craftsman != null) {
            val updated = craftsman.copy(
                overallRating = average,
                reviewCount = count
            )
            dao.updateCraftsman(updated)
        }
    }

    // Professions
    val allProfessions: Flow<List<Profession>> = dao.getAllProfessions()

    suspend fun insertProfession(profession: Profession) {
        dao.insertProfession(profession)
    }

    suspend fun deleteProfessionById(id: Int) {
        dao.deleteProfessionById(id)
    }

    // AdBanners
    val allAdBanners: Flow<List<AdBanner>> = dao.getAllAdBanners()

    suspend fun insertAdBanner(adBanner: AdBanner) {
        dao.insertAdBanner(adBanner)
    }

    suspend fun deleteAdBannerById(id: Int) {
        dao.deleteAdBannerById(id)
    }

    // ChatMessages
    fun getChatMessages(craftsmanId: Int): Flow<List<ChatMessage>> =
        dao.getChatMessages(craftsmanId)

    suspend fun insertChatMessage(message: ChatMessage) {
        dao.insertChatMessage(message)
    }

    suspend fun clearChat(craftsmanId: Int) {
        dao.clearChat(craftsmanId)
    }

    // AppSettings
    val appSettings: Flow<AppSettings?> = dao.getAppSettingsFlow()

    suspend fun getAppSettingsSync(): AppSettings? = dao.getAppSettingsSync()

    suspend fun insertAppSettings(settings: AppSettings) {
        dao.insertAppSettings(settings)
    }
}
