package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Helper extension to dynamically parse Hex Colors saved by Admin
fun String.toComposeColor(): Color {
    return try {
        Color(android.graphics.Color.parseColor(this))
    } catch (e: Exception) {
        Color(0xFF2E7D32) // Default Palm Green
    }
}

// Convert timestamp to neat Arabic date
fun Long.toFormattedArabicDate(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale("ar"))
    return sdf.format(Date(this))
}

@Composable
fun PalmLogo(modifier: Modifier = Modifier, color: Color = Color(0xFF2E7D32)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        
        // Trunk (الجذع)
        val trunkPath = Path().apply {
            moveTo(w * 0.48f, h * 0.95f)
            quadraticTo(w * 0.52f, h * 0.70f, w * 0.50f, h * 0.45f)
            lineTo(w * 0.45f, h * 0.45f)
            quadraticTo(w * 0.47f, h * 0.70f, w * 0.42f, h * 0.95f)
            close()
        }
        drawPath(trunkPath, color = color)

        // Draw geometric segments on trunk
        for (i in 0..5) {
            val yFactor = 0.50f + (i * 0.08f)
            val y = h * yFactor
            val x = w * (0.45f + i * 0.015f)
            drawCircle(color = Color(0x35000000), radius = 3.dp.toPx(), center = Offset(x, y))
        }

        // Draw 7 palm leaves (الخوص والجريد) symmetrically as geometric lines
        val branchPoints = listOf(
            // Top central
            Offset(w * 0.48f, h * 0.45f) to Offset(w * 0.48f, h * 0.15f),
            // Left branches
            Offset(w * 0.48f, h * 0.45f) to Offset(w * 0.20f, h * 0.25f),
            Offset(w * 0.48f, h * 0.45f) to Offset(w * 0.15f, h * 0.42f),
            Offset(w * 0.48f, h * 0.45f) to Offset(w * 0.25f, h * 0.60f),
            // Right branches
            Offset(w * 0.48f, h * 0.45f) to Offset(w * 0.76f, h * 0.25f),
            Offset(w * 0.48f, h * 0.45f) to Offset(w * 0.81f, h * 0.42f),
            Offset(w * 0.48f, h * 0.45f) to Offset(w * 0.71f, h * 0.60f)
        )

        branchPoints.forEach { (start, end) ->
            // Path structure for geometric palm frond leafiness
            val leafPath = Path().apply {
                moveTo(start.x, start.y)
                quadraticTo((start.x + end.x) / 2f, (start.y + end.y) / 2f - 15.dp.toPx(), end.x, end.y)
                quadraticTo((start.x + end.x) / 2f + 5.dp.toPx(), (start.y + end.y) / 2f, start.x, start.y)
            }
            drawPath(leafPath, color = color)
        }
    }
}

enum class ActiveScreen {
    HOME,
    CRAFTSMAN_DETAIL,
    EDIT_PROFILE,
    CHAT,
    ADMIN_DASHBOARD,
    ABOUT
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppUi(viewModel: AppViewModel) {
    val currentViewScreen = remember { mutableStateFlowScreen(ActiveScreen.HOME) }
    
    val appSettings by viewModel.appSettings.collectAsState()
    val primaryColor = appSettings.primaryColorHex.toComposeColor()
    val rawBgColor = appSettings.backgroundColorHex.toComposeColor()
    
    // Maintain layout direction to RTL for Iraq/Arabic Theme
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = rawBgColor
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Scaffold(
                    topBar = {
                        AppTopBar(
                            viewModel = viewModel,
                            appSettings = appSettings,
                            primaryColor = primaryColor,
                            currentScreenState = currentViewScreen
                        )
                    },
                    bottomBar = {
                        AppBottomNavigation(
                            themeColor = primaryColor,
                            currentScreenState = currentViewScreen,
                            viewModel = viewModel
                        )
                    },
                    containerColor = rawBgColor
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = currentViewScreen.value,
                            transitionSpec = {
                                fadeIn(animationSpec = spring()) togetherWith fadeOut(animationSpec = spring())
                            },
                            label = "screen_transition"
                        ) { screen ->
                            when (screen) {
                                ActiveScreen.HOME -> HomeScreen(
                                    viewModel = viewModel,
                                    primaryColor = primaryColor,
                                    currentScreenState = currentViewScreen
                                )
                                ActiveScreen.CRAFTSMAN_DETAIL -> CraftsmanDetailScreen(
                                    viewModel = viewModel,
                                    primaryColor = primaryColor,
                                    currentScreenState = currentViewScreen
                                )
                                ActiveScreen.EDIT_PROFILE -> EditProfileScreen(
                                    viewModel = viewModel,
                                    primaryColor = primaryColor,
                                    currentScreenState = currentViewScreen
                                )
                                ActiveScreen.CHAT -> ChatScreen(
                                    viewModel = viewModel,
                                    primaryColor = primaryColor,
                                    currentScreenState = currentViewScreen
                                )
                                ActiveScreen.ADMIN_DASHBOARD -> AdminDashboardScreen(
                                    viewModel = viewModel,
                                    primaryColor = primaryColor,
                                    currentScreenState = currentViewScreen
                                )
                                ActiveScreen.ABOUT -> AboutScreen(
                                    primaryColor = primaryColor
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Custom simple helper state wrapper
class MutableStateFlowScreen(initial: ActiveScreen) {
    private val state = mutableStateOf(initial)
    var value: ActiveScreen
        get() = state.value
        set(v) { state.value = v }
}

@Composable
fun rememberMutableStateFlowScreen(initial: ActiveScreen) = remember { mutableStateOf(initial) }

fun mutableStateFlowScreen(initial: ActiveScreen): MutableState<ActiveScreen> {
    return mutableStateOf(initial)
}

@Composable
fun AppTopBar(
    viewModel: AppViewModel,
    appSettings: AppSettings,
    primaryColor: Color,
    currentScreenState: MutableState<ActiveScreen>
) {
    val currentRole by viewModel.currentRole.collectAsState()
    
    Card(
        shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
        colors = CardDefaults.cardColors(containerColor = primaryColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(top = 12.dp, bottom = 12.dp, start = 16.dp, end = 16.dp)) {
            // High-fidelity Iraqi branding header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Logo & App Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PalmLogo(
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color.White, CircleShape)
                            .padding(4.dp),
                        color = primaryColor
                    )
                    Column {
                        Text(
                            text = "حرفيي العراق",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "منصة ربط مجتمعية مجانية بالكامل",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }

                // Interactive Roles Toggles
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White.copy(alpha = 0.22f),
                    modifier = Modifier.padding(start = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(2.dp),
                        horizontalArrangement = Arrangement.spacedBy(1.dp)
                    ) {
                        RoleBadge(
                            title = "زبون",
                            isActive = (currentRole == "customer"),
                            onClick = { viewModel.switchRole("customer") }
                        )
                        RoleBadge(
                            title = "حرفي",
                            isActive = (currentRole == "craftsman"),
                            onClick = { 
                                viewModel.switchRole("craftsman")
                                currentScreenState.value = ActiveScreen.EDIT_PROFILE
                            }
                        )
                        RoleBadge(
                            title = "الادارة",
                            isActive = (currentRole == "admin"),
                            onClick = {
                                viewModel.switchRole("admin")
                                currentScreenState.value = ActiveScreen.ADMIN_DASHBOARD
                            }
                        )
                    }
                }
            }
            
            // App settings welcome message below logo
            if (currentScreenState.value == ActiveScreen.HOME) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Welcome",
                        tint = Color(0xFFFFD700),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = appSettings.welcomeText,
                        fontSize = 11.sp,
                        color = Color.White.copy(0.95f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
fun RowScope.RoleBadge(title: String, isActive: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isActive) Color.White else Color.Transparent,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp)
    ) {
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            color = if (isActive) Color.Black else Color.White,
            modifier = Modifier.padding(vertical = 4.dp, horizontal = 10.dp)
        )
    }
}

@Composable
fun AppBottomNavigation(
    themeColor: Color,
    currentScreenState: MutableState<ActiveScreen>,
    viewModel: AppViewModel
) {
    val currentRole by viewModel.currentRole.collectAsState()
    
    Card(
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        NavigationBar(
            containerColor = Color.Transparent,
            windowInsets = WindowInsets.navigationBars
        ) {
            NavigationBarItem(
                selected = (currentScreenState.value == ActiveScreen.HOME),
                onClick = { currentScreenState.value = ActiveScreen.HOME },
                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                label = { Text("الرئيسية", fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = themeColor,
                    selectedTextColor = themeColor,
                    indicatorColor = themeColor.copy(alpha = 0.15f)
                )
            )

            if (currentRole == "craftsman") {
                NavigationBarItem(
                    selected = (currentScreenState.value == ActiveScreen.EDIT_PROFILE),
                    onClick = { currentScreenState.value = ActiveScreen.EDIT_PROFILE },
                    icon = { Icon(Icons.Default.Build, contentDescription = "My Profile") },
                    label = { Text("حرفي بلس", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = themeColor,
                        selectedTextColor = themeColor,
                        indicatorColor = themeColor.copy(alpha = 0.15f)
                    )
                )
            } else if (currentRole == "admin") {
                NavigationBarItem(
                    selected = (currentScreenState.value == ActiveScreen.ADMIN_DASHBOARD),
                    onClick = { currentScreenState.value = ActiveScreen.ADMIN_DASHBOARD },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Control Panel") },
                    label = { Text("لوحة الإدارة", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = themeColor,
                        selectedTextColor = themeColor,
                        indicatorColor = themeColor.copy(alpha = 0.15f)
                    )
                )
            }

            NavigationBarItem(
                selected = (currentScreenState.value == ActiveScreen.ABOUT),
                onClick = { currentScreenState.value = ActiveScreen.ABOUT },
                icon = { Icon(Icons.Default.Info, contentDescription = "About App") },
                label = { Text("حول التطبيق", fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = themeColor,
                    selectedTextColor = themeColor,
                    indicatorColor = themeColor.copy(alpha = 0.15f)
                )
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MarqueeBanner(banners: List<AdBanner>, primaryColor: Color) {
    if (banners.isEmpty()) return
    
    val completeTickerText = remember(banners) {
        banners.joinToString("   ⚡   ") { it.text } + "   ⚡   "
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF9C4)), // Highlight Yellow Tint
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .padding(vertical = 6.dp, horizontal = 12.dp)
                .fillMaxWidth()
        ) {
            // Stationary Tag badge
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = primaryColor,
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Text(
                    text = "تنبيه إداري متحرك",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            // Real smooth marquee scrolling text
            Text(
                text = completeTickerText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF5D4037),
                maxLines = 1,
                modifier = Modifier
                    .weight(1f)
                    .basicMarquee(iterations = Int.MAX_VALUE)
            )
        }
    }
}

@Composable
fun HomeScreen(
    viewModel: AppViewModel,
    primaryColor: Color,
    currentScreenState: MutableState<ActiveScreen>
) {
    val searchVal by viewModel.searchQuery.collectAsState()
    val rawBanners by viewModel.allAdBanners.collectAsState()
    val professions by viewModel.allProfessions.collectAsState()
    val activeProfessionFilter by viewModel.selectedProfession.collectAsState()
    val craftsmenList by viewModel.filteredCraftsmen.collectAsState()
    
    Column(modifier = Modifier.fillMaxSize()) {
        // 1. Moving alert marquee ticker
        MarqueeBanner(banners = rawBanners, primaryColor = primaryColor)

        // 2. Search Area
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchVal,
                onValueChange = { viewModel.searchQuery.value = it },
                placeholder = { Text("ابحث عن حرفي بالاسم، السيرة الذاتية أو المهنة...", fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search icon") },
                trailingIcon = {
                    if (searchVal.isNotEmpty()) {
                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = primaryColor,
                    unfocusedBorderColor = Color.LightGray
                ),
                modifier = Modifier.weight(1f)
            )
        }

        // 3. Section/Trade Grid (قائمة المهن الفاخرة بدون كروت - قائمة مهن مستعرضة أنيقة)
        Text(
            text = "المهن والأقسام المتاحة",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color.DarkGray,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (activeProfessionFilter == null) primaryColor.copy(alpha = 0.2f) else Color.Transparent,
                    border = BorderStroke(1.dp, if (activeProfessionFilter == null) primaryColor else Color.LightGray),
                    modifier = Modifier.clickable { viewModel.selectedProfession.value = null }
                ) {
                    Text(
                        text = "الكل 📋",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (activeProfessionFilter == null) primaryColor else Color.Black,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }

            items(professions) { prof ->
                val isSelected = activeProfessionFilter == prof.name
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isSelected) primaryColor.copy(alpha = 0.2f) else Color.Transparent,
                    border = BorderStroke(1.dp, if (isSelected) primaryColor else Color.LightGray),
                    modifier = Modifier.clickable { viewModel.selectedProfession.value = prof.name }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = prof.name,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) primaryColor else Color.Black
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "🛠️", fontSize = 10.sp)
                    }
                }
            }
        }

        Divider(modifier = Modifier.padding(vertical = 10.dp), color = Color.LightGray.copy(alpha = 0.5f))

        // 4. Craftsmen list
        Text(
            text = "الحرفيون المسجلون (${craftsmenList.size})",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        if (craftsmenList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "Empty list",
                        tint = Color.LightGray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "لا يوجد حرفيون يطابقون خيارات البحث حالياً.",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "اضغط على زر الادارة لتسويق حرفي جديد فوراً!",
                        fontSize = 11.sp,
                        color = primaryColor,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 80.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(craftsmenList) { craftsman ->
                    CraftsmanItemCard(
                        craftsman = craftsman,
                        primaryColor = primaryColor,
                        onClick = {
                            viewModel.selectCraftsman(craftsman.id)
                            currentScreenState.value = ActiveScreen.CRAFTSMAN_DETAIL
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun CraftsmanItemCard(
    craftsman: Craftsman,
    primaryColor: Color,
    onClick: () -> Unit
) {
    if (craftsman.isBlocked) return // Do not show blocked accounts in general listings

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Profile Portrait
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(primaryColor.copy(0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = craftsman.name.firstOrNull()?.toString() ?: "ح",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = primaryColor
                )
            }
            
            Spacer(modifier = Modifier.width(14.dp))

            // Information Center
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = craftsman.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    if (craftsman.isVerified) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Verified Craftsman",
                            tint = Color(0xFF00C853),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                
                Text(
                    text = craftsman.profession,
                    fontSize = 12.sp,
                    color = primaryColor,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(vertical = 2.dp)
                )

                Text(
                    text = craftsman.bio,
                    fontSize = 11.sp,
                    color = Color.Gray,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Dynamic Star rating panel in RTL
            Column(horizontalAlignment = Alignment.End) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Rating",
                        tint = Color(0xFFFFB300),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        // Iraqi layout requested western numerals (0,1,2,3)
                        text = String.format(Locale.ENGLISH, "%.1f", craftsman.overallRating),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
                
                Text(
                    text = "${craftsman.reviewCount} تقييم",
                    fontSize = 10.sp,
                    color = Color.DarkGray
                )
                
                Spacer(modifier = Modifier.height(10.dp))
                
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "More details",
                    tint = Color.LightGray
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CraftsmanDetailScreen(
    viewModel: AppViewModel,
    primaryColor: Color,
    currentScreenState: MutableState<ActiveScreen>
) {
    val craftsman by viewModel.selectedCraftsman.collectAsState()
    val reviews by viewModel.selectedCraftsmanReviews.collectAsState()
    
    // User profile ratings inputs
    var clientName by remember { mutableStateOf("") }
    var starRatingInput by remember { mutableStateOf(5) }
    var clientCommentInput by remember { mutableStateOf("") }
    val showSnackbar = rememberInternalToast()
    
    if (craftsman == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("جاري تحميل بيانات الحرفي...")
                Button(onClick = { currentScreenState.value = ActiveScreen.HOME }) {
                    Text("الرجوع للرئيسية")
                }
            }
        }
        return
    }

    val activeCraftsman = craftsman!!

    LazyColumn(contentPadding = PaddingValues(bottom = 100.dp)) {
        // Back Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                IconButton(onClick = { currentScreenState.value = ActiveScreen.HOME }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Go Back")
                }
                Text("الملف التعريفي للحرفي", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }

        // 1. Hero identity card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(primaryColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = activeCraftsman.name.firstOrNull()?.toString() ?: "",
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = activeCraftsman.name,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        if (activeCraftsman.isVerified) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified Identity",
                                tint = Color(0xFF00C853),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Text(
                        text = activeCraftsman.profession,
                        fontSize = 14.sp,
                        color = primaryColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    // Large stars rating presentation
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (i in 1..5) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "$i Stars",
                                tint = if (i <= activeCraftsman.overallRating) Color(0xFFFFB300) else Color.LightGray,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${String.format(Locale.ENGLISH, "%.1f", activeCraftsman.overallRating)} (${activeCraftsman.reviewCount} تقييم)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.DarkGray
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Live communication actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { currentScreenState.value = ActiveScreen.CHAT },
                            colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Email, contentDescription = "Direct Chat")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("افتح شات التواصل", fontSize = 12.sp, color = Color.White)
                        }

                        OutlinedButton(
                            onClick = {
                                // Simulate dialing
                                showSnackbar.show("تم نسخ رقم هاتف الحرفي (${activeCraftsman.phone}) للاتصال المباشر!")
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = "Call phone", tint = primaryColor)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اتصال مباشر", fontSize = 12.sp, color = primaryColor)
                        }
                    }
                }
            }
        }

        // 2. CV and Biography
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "السيرة الذاتية وتفاصيل الخبرة",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = activeCraftsman.bio,
                        fontSize = 12.sp,
                        color = Color.DarkGray,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "رقم هاتف مباشر: ${activeCraftsman.phone}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor
                    )
                }
            }
        }

        // 3. Work Portfolio (معرض الصور)
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "صور من أعمال الحرفي السابقة",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    val imageList = activeCraftsman.portfolioImagesStr.split(";").filter { it.isNotBlank() }
                    
                    if (imageList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("لم يقم الحرفي برفع صور لأعماله بعد.", fontSize = 11.sp, color = Color.Gray)
                        }
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(imageList) { imgKey ->
                                PortfolioImagePlaceholder(imageName = imgKey, themeColor = primaryColor)
                            }
                        }
                    }
                }
            }
        }

        // 4. MANDATORY REVIEW/COMMENT SUBMISSION FORM
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)), // Clean Green Glow Tonal
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "✍️ قيم الحرفي واكتب تعليقك (مطلوب لإتمام العملية)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor
                    )
                    Text(
                        text = "تطبيق حرفيي العراق يعتمد مبدأ الشفافية والتقييم الحقيقي من الزبائن بعد كل خدمة.",
                        fontSize = 10.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(vertical = 3.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Star selector interactive
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (star in 1..5) {
                            IconButton(onClick = { starRatingInput = star }) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "$star Stars",
                                    tint = if (star <= starRatingInput) Color(0xFFFFB300) else Color.LightGray,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = clientName,
                        onValueChange = { clientName = it },
                        label = { Text("اسمك الكريم (أو اتركه مجهول)", fontSize = 11.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = primaryColor),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = clientCommentInput,
                        onValueChange = { clientCommentInput = it },
                        label = { Text("اكتب رأيك بأمانة ومصداقية (إلزامي)*", fontSize = 11.sp) },
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = primaryColor),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (clientCommentInput.isBlank()) {
                                showSnackbar.show("الرجاء كتابة تعليق حقيقي (التعليق إجباري لضمان دقة النظام)!")
                            } else {
                                viewModel.submitReview(
                                    craftsmanId = activeCraftsman.id,
                                    customerName = clientName,
                                    rating = starRatingInput,
                                    comment = clientCommentInput
                                )
                                showSnackbar.show("تم تدوين تقييمك بنجاح! شكرًا لتعاونك.")
                                // reset inputs
                                clientCommentInput = ""
                                clientName = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("إرسال التقييم والتعليق الآن", fontSize = 12.sp, color = Color.White)
                    }
                }
            }
        }

        // 5. Customer Review Catalog
        item {
            Text(
                text = "سجل التعليقات والآراء لهذا الحرفي (${reviews.size})",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 4.dp)
            )
        }

        if (reviews.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("لا تتوفر تعليقات معتمدة لهذا الحرفي حتى الآن.", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else {
            items(reviews) { review ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.LightGray.copy(0.3f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = review.customerName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                            
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                for (star in 1..5) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = if (star <= review.rating) Color(0xFFFFB300) else Color.LightGray,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = review.comment,
                            fontSize = 12.sp,
                            color = Color.DarkGray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Text(
                            text = review.timestamp.toFormattedArabicDate(),
                            fontSize = 9.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.End,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }

    // Dynamic Snackbar Popup Rendering
    showSnackbar.Render()
}

@Composable
fun PortfolioImagePlaceholder(imageName: String, themeColor: Color) {
    // Generate lovely themed placeholders instead of broken real URLs so visual preview stays 100% pristine.
    val label = when {
        imageName.contains("plumb") -> "تمديد ونظافة صحية 💧"
        imageName.contains("elec") -> "بورادات وتسليك أمان ⚡"
        imageName.contains("carp") -> "نجارة وتفصال غرف نوم 🪵"
        imageName.contains("paint") -> "طلاء جدران مودرن 🎨"
        else -> "عمل منجز بدقة 🛠️"
    }

    Box(
        modifier = Modifier
            .size(130.dp, 100.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(themeColor.copy(alpha = 0.5f), themeColor)
                )
            )
            .border(1.dp, Color.White, remember { RoundedCornerShape(8.dp) }),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(6.dp)
        ) {
            Icon(Icons.Default.Star, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center,
                lineHeight = 12.sp
            )
        }
    }
}

@Composable
fun EditProfileScreen(
    viewModel: AppViewModel,
    primaryColor: Color,
    currentScreenState: MutableState<ActiveScreen>
) {
    val loggedInId by viewModel.loggedInCraftsmanId.collectAsState()
    val list by viewModel.filteredCraftsmen.collectAsState()
    val professions by viewModel.allProfessions.collectAsState()
    
    // Find logged in craftsman
    val myProfile = list.firstOrNull { it.id == loggedInId }
    
    // Inputs state
    var editName by remember { mutableStateOf("") }
    var editBio by remember { mutableStateOf("") }
    var editPhone by remember { mutableStateOf("") }
    var editProfession by remember { mutableStateOf("") }
    var editAvatarUrl by remember { mutableStateOf("") }
    val showSnackbar = rememberInternalToast()

    // Initialize inputs when data loaded
    LaunchedEffect(myProfile) {
        myProfile?.let {
            editName = it.name
            editBio = it.bio
            editPhone = it.phone
            editProfession = it.profession
            editAvatarUrl = it.avatarUrl
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 80.dp),
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "⚙️ لوحة تعديل ملف الحرفي",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Text(
                text = "قم بتحديث معلوماتك العامة ليرى الزبائن سيرة ذاتية واضحة وموثوقة.",
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        if (myProfile == null) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("تعذر التعرف على حساب الحرفي المسجل.")
                }
            }
        } else {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("الاسم الكامل الحقيقي", fontSize = 11.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = primaryColor),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Selection of Profession Dropdown simulation
                        Text(
                            text = "اختر المهنة المتخصصة بها*",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(professions) { prof ->
                                val active = editProfession == prof.name
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (active) primaryColor else Color.LightGray.copy(0.3f),
                                    modifier = Modifier.clickable { editProfession = prof.name }
                                ) {
                                    Text(
                                        text = prof.name,
                                        fontSize = 10.sp,
                                        color = if (active) Color.White else Color.Black,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = editPhone,
                            onValueChange = { editPhone = it },
                            label = { Text("رقم هاتفك للتواصل المباشر", fontSize = 11.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = primaryColor),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = editBio,
                            onValueChange = { editBio = it },
                            label = { Text("اكتب سيرتك ومهاراتك الحرفية لخدمة زملائك", fontSize = 11.sp) },
                            maxLines = 5,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = primaryColor),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (editName.isBlank() || editBio.isBlank() || editPhone.isBlank()) {
                                    showSnackbar.show("الرجاء ملء كافة خانات البيانات!")
                                } else {
                                    viewModel.saveCraftsmanProfile(
                                        id = myProfile.id,
                                        name = editName,
                                        bio = editBio,
                                        phone = editPhone,
                                        profession = editProfession,
                                        avatarUrl = editAvatarUrl
                                    )
                                    showSnackbar.show("تم تحديث معلوماتك الحرفية بنجاح على قاعدة البيانات!")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("حفظ التغييرات الآن", fontSize = 12.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }

    showSnackbar.Render()
}

@Composable
fun ChatScreen(
    viewModel: AppViewModel,
    primaryColor: Color,
    currentScreenState: MutableState<ActiveScreen>
) {
    val craftsman by viewModel.selectedCraftsman.collectAsState()
    val chatMessages by viewModel.activeChatMessages.collectAsState()
    
    var currentTextText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val showSnackbar = rememberInternalToast()
    
    if (craftsman == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Button(onClick = { currentScreenState.value = ActiveScreen.HOME }) {
                Text("الرجوع للرئيسية")
            }
        }
        return
    }

    val activeCraftsman = craftsman!!

    // Auto-scroll to bottom when messages update
    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Chat Header with status
        Card(
            shape = RoundedCornerShape(0.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                IconButton(onClick = { currentScreenState.value = ActiveScreen.CRAFTSMAN_DETAIL }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(primaryColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = activeCraftsman.name.firstOrNull()?.toString() ?: "",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = activeCraftsman.name, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        if (activeCraftsman.isVerified) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF00C853), modifier = Modifier.size(14.dp))
                        }
                    }
                    Text(text = "نشط الآن بقوة • ${activeCraftsman.profession}", fontSize = 10.sp, color = Color.Gray)
                }
            }
        }

        // Messages Box
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFFEDE7F6).copy(0.3f)) // Bubble Background Tint
        ) {
            items(chatMessages) { message ->
                val isMe = message.senderId == "customer"
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isMe) Arrangement.Start else Arrangement.End
                ) {
                    Card(
                        shape = RoundedCornerShape(
                            topStart = 12.dp,
                            topEnd = 12.dp,
                            bottomStart = if (isMe) 0.dp else 12.dp,
                            bottomEnd = if (isMe) 12.dp else 0.dp
                        ),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isMe) primaryColor else Color.White
                        ),
                        modifier = Modifier
                            .widthIn(max = 280.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = message.text,
                                fontSize = 12.sp,
                                color = if (isMe) Color.White else Color.Black
                            )
                            
                            // Audio simulation visually
                            if (message.voiceDuration > 0) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = if (isMe) Color.White else primaryColor)
                                    // Make drawing waves
                                    Canvas(modifier = Modifier.size(80.dp, 16.dp)) {
                                        val waveWidth = size.width
                                        val waveHeight = size.height
                                        val steps = 8
                                        for (i in 0 until steps) {
                                            val x = (waveWidth / steps) * i + (waveWidth / steps) / 2
                                            val hLine = (3..12).random().dp.toPx()
                                            drawLine(
                                                color = if (isMe) Color.White else primaryColor,
                                                start = Offset(x, waveHeight/2 - hLine/2),
                                                end = Offset(x, waveHeight/2 + hLine/2),
                                                strokeWidth = 2.dp.toPx(),
                                                cap = StrokeCap.Round
                                            )
                                        }
                                    }
                                    Text(
                                        text = "0:${String.format(Locale.ENGLISH, "%02d", message.voiceDuration)}",
                                        fontSize = 9.sp,
                                        color = if (isMe) Color.White.copy(0.7f) else Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Input Box (text, voice, location, dummy photos)
        Card(
            shape = RoundedCornerShape(0.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                // Attachments row (voice, mock locations, clear history)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(onClick = {
                        viewModel.sendChatMessage(activeCraftsman.id, "", sender = "customer", isLocation = true)
                        showSnackbar.show("📍 تم إرسال لوكيشن بيتك للحرفي لتسهيل تتبعه!")
                    }) {
                        Icon(Icons.Default.LocationOn, contentDescription = "Send map location", tint = primaryColor)
                    }

                    IconButton(onClick = {
                        viewModel.sendChatMessage(activeCraftsman.id, "", sender = "customer", isVoice = true)
                        showSnackbar.show("🎙️ تم تسجيل وإرسال بصمة صوتية للحرفي!")
                    }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Send voice note", tint = primaryColor)
                    }

                    IconButton(onClick = {
                        showSnackbar.show("📸 نظام المعاينة: تم رفع وإرسال صورة المشكلة للحرفي للاطلاع عليها!")
                        viewModel.sendChatMessage(activeCraftsman.id, "🖼️ تم مشاركة صورة من معرض الهاتف للمشكلة الحاصلة.", sender = "customer")
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Insert photo", tint = primaryColor)
                    }

                    IconButton(onClick = {
                        viewModel.clearChat(activeCraftsman.id)
                        showSnackbar.show("تم تصفير شريط محادثة الحرفي تمهيداً لبداية جديدة!")
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = "Flush conversation logs", tint = Color.Red)
                    }
                }
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = currentTextText,
                        onValueChange = { currentTextText = it },
                        placeholder = { Text("اكتب رسالتك للحرفي هنا...", fontSize = 12.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = primaryColor),
                        modifier = Modifier.weight(1f)
                    )

                    FloatingActionButton(
                        onClick = {
                            if (currentTextText.isNotBlank()) {
                                viewModel.sendChatMessage(activeCraftsman.id, currentTextText, sender = "customer")
                                currentTextText = ""
                            }
                        },
                        containerColor = primaryColor,
                        contentColor = Color.White,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send message")
                    }
                }
            }
        }
    }

    showSnackbar.Render()
}

@Composable
fun AdminDashboardScreen(
    viewModel: AppViewModel,
    primaryColor: Color,
    currentScreenState: MutableState<ActiveScreen>
) {
    val isAdminAuth by viewModel.isAdminAuthenticated.collectAsState()
    
    // Auth logic Inputs
    var phoneInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    val showSnackbar = rememberInternalToast()

    if (!isAdminAuth) {
        // High fidelity elegant Admin sign in page
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PalmLogo(modifier = Modifier.size(60.dp), color = primaryColor)
                    Text("بوابة تسجيل المشرف (المدير المحلي)", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("أدخل رقم هاتف المدير وكلمة السر المبرمجة بالكامل في قاعدة البيانات للدخول لوحة التحكم اللاسلكية.", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)

                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("رقم هاتف المشرف", fontSize = 11.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("كلمة السر الخاصة باللوحة", fontSize = 11.sp) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val success = viewModel.loginAdmin(phoneInput, passwordInput)
                            if (success) {
                                showSnackbar.show("تم التحقق بنجاح! مرحباً بالمدير حسين الدخيل.")
                            } else {
                                showSnackbar.show("❌ خيانة البيانات! كلمة سر المشرف أو رقم الهاتف غير مطابق.")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("دخول سريع للوحة التحكم", color = Color.White, fontSize = 12.sp)
                    }
                    
                    Text(
                        text = "التفاصيل الافتراضية للمشرف: الهاتف 07740400741 • الرمز 19851985",
                        fontSize = 10.sp,
                        color = Color.LightGray
                    )
                }
            }
        }
        showSnackbar.Render()
        return
    }

    // AUTHENTICATED WEB CONTROL PORTAL
    var settingsTabActive by remember { mutableStateOf(0) } // 0: Content, 1: Industries, 2: Ads, 3: Accounts, 4: Reviews, 5: Firebase
    
    Column(modifier = Modifier.fillMaxSize()) {
        // Tab Navigation inside panel
        ScrollableTabRow(
            selectedTabIndex = settingsTabActive,
            edgePadding = 12.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[settingsTabActive]),
                    color = primaryColor
                )
            }
        ) {
            Tab(selected = (settingsTabActive == 0), onClick = { settingsTabActive = 0 }) {
                Text("المظهر والمحتوى", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
            }
            Tab(selected = (settingsTabActive == 1), onClick = { settingsTabActive = 1 }) {
                Text("المهن والأقسام", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
            }
            Tab(selected = (settingsTabActive == 2), onClick = { settingsTabActive = 2 }) {
                Text("شريط الإعلانات", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
            }
            Tab(selected = (settingsTabActive == 3), onClick = { settingsTabActive = 3 }) {
                Text("الحسابات والتراخيص", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
            }
            Tab(selected = (settingsTabActive == 4), onClick = { settingsTabActive = 4 }) {
                Text("الرقابة والتعليقات", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
            }
            Tab(selected = (settingsTabActive == 5), onClick = { settingsTabActive = 5 }) {
                Text("سحابة Firebase", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
            }
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (settingsTabActive) {
                0 -> AdminContentSettingsView(viewModel, primaryColor)
                1 -> AdminIndustriesView(viewModel, primaryColor)
                2 -> AdminBannersView(viewModel, primaryColor)
                3 -> AdminAccountsView(viewModel, primaryColor)
                4 -> AdminReviewsModerationView(viewModel, primaryColor)
                5 -> AdminFirebaseSyncView(viewModel, primaryColor)
            }
        }
    }
}

@Composable
fun AdminContentSettingsView(viewModel: AppViewModel, primaryColor: Color) {
    val settings by viewModel.appSettings.collectAsState()
    
    // Inputs state
    var editWelcText by remember { mutableStateOf("") }
    var editPhoneAdmin by remember { mutableStateOf("") }
    var editPassAdmin by remember { mutableStateOf("") }
    var colorSelectionHex by remember { mutableStateOf("") }
    val showSnackbar = rememberInternalToast()

    LaunchedEffect(settings) {
        editWelcText = settings.welcomeText
        editPhoneAdmin = settings.managerPhone
        editPassAdmin = settings.managerPassword
        colorSelectionHex = settings.primaryColorHex
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("🎨 ألوان وهوية التطبيق", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("ضبط ألوان الواجهات الرئيسية فوراً (تخصيص ثيم الألوان)", fontSize = 11.sp, color = Color.Gray)
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    // Quick pre-selected colors
                    val listPalettes = listOf("#2E7D32" to "أخضر نخلة", "#008080" to "سيلان فيروزي", "#5C6BC0" to "أزرق دجلة", "#D81B60" to "ياقوت وردي", "#E65100" to "طين بابلي")
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listPalettes.forEach { (hex, name) ->
                            val active = colorSelectionHex.lowercase() == hex.lowercase()
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(35.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(hex.toComposeColor())
                                    .border(BorderStroke(2.dp, if (active) Color.Black else Color.White), RoundedCornerShape(8.dp))
                                    .clickable { colorSelectionHex = hex },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(name, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = colorSelectionHex,
                        onValueChange = { colorSelectionHex = it },
                        label = { Text("رمز اللون اليدوي (Hex Color)", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("📢 نصوص ونظام الترحيب الأساسي", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    OutlinedTextField(
                        value = editWelcText,
                        onValueChange = { editWelcText = it },
                        label = { Text("نص الترحيب في الشريط الأعلى", fontSize = 11.sp) },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("🔐 أمن المشرف (بيانات لوحة المدير)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("قم بتغيير رقم هاتف المدير وكلمة سره للتأمين الكامل.", fontSize = 11.sp, color = Color.Gray)
                    
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = editPhoneAdmin,
                        onValueChange = { editPhoneAdmin = it },
                        label = { Text("رقم هاتف المشرف الجديد", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = editPassAdmin,
                        onValueChange = { editPassAdmin = it },
                        label = { Text("رمز المرور السري الجديد", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item {
            Button(
                onClick = {
                    if (colorSelectionHex.isBlank() || editWelcText.isBlank() || editPhoneAdmin.isBlank() || editPassAdmin.isBlank()) {
                        showSnackbar.show("الرجاء عدم ترك أي معلومات فارغة!")
                    } else {
                        viewModel.updateAppColorsAndStyle(colorSelectionHex, editWelcText)
                        viewModel.updateAdminCredentials(editPhoneAdmin, editPassAdmin)
                        showSnackbar.show("تم حفظ الإعدادات بنجاح! وسوف تنعكس الألوان الحرفية فوراً.")
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("حفظ التغييرات الشاملة للمحتوى والهوية", color = Color.White, fontSize = 12.sp)
            }
        }
    }

    showSnackbar.Render()
}

@Composable
fun AdminIndustriesView(viewModel: AppViewModel, primaryColor: Color) {
    val professions by viewModel.allProfessions.collectAsState()
    var inputProfName by remember { mutableStateOf("") }
    val showSnackbar = rememberInternalToast()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("🏢 المهن والأقسام الحرفية المتاحة", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text("أضف مهنة جديدة فوراً لتظهر في لوحة الفلترة والفرز في الصفحة الرئيسية.", fontSize = 11.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputProfName,
                onValueChange = { inputProfName = it },
                placeholder = { Text("مثال: مهندس زراعي، تصليح غسالات...", fontSize = 11.sp) },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )

            Button(
                onClick = {
                    if (inputProfName.isNotBlank()) {
                        viewModel.addProfession(inputProfName)
                        showSnackbar.show("تم إضافة مهنة ($inputProfName) لقائمة الحرفيين بنجاح!")
                        inputProfName = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("إضافة مهنة", color = Color.White, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(professions) { prof ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.LightGray.copy(0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🛠️", fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = prof.name, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        IconButton(onClick = {
                            viewModel.deleteProfession(prof.id)
                            showSnackbar.show("تم إزالة قسم (${prof.name}) بنجاح.")
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove craft", tint = Color.Red)
                        }
                    }
                }
            }
        }
    }

    showSnackbar.Render()
}

@Composable
fun AdminBannersView(viewModel: AppViewModel, primaryColor: Color) {
    val banners by viewModel.allAdBanners.collectAsState()
    var inputBannerText by remember { mutableStateOf("") }
    var inputBannerLink by remember { mutableStateOf("") }
    val showSnackbar = rememberInternalToast()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("📢 متحرك الإعلانات والتنبيهات السريعة", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text("أضف جمل وملاحظات تظهر لجميع الزوار بشعار حرفيي العراق بشكل متحرك.", fontSize = 11.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = inputBannerText,
            onValueChange = { inputBannerText = it },
            label = { Text("اكتب نص الإعلان المتحرك", fontSize = 11.sp) },
            maxLines = 2,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = inputBannerLink,
            onValueChange = { inputBannerLink = it },
            label = { Text("رابط الإعلان الإضافي (اختياري)", fontSize = 11.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = {
                if (inputBannerText.isNotBlank()) {
                    viewModel.addAdBanner(inputBannerText, inputBannerLink)
                    showSnackbar.show("تم إدراج التنبيه المتداول الجديد!")
                    inputBannerText = ""
                    inputBannerLink = ""
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("إطلاق ونشر الإعلان المتحرك فوراً", color = Color.White, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(banners) { banner ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = banner.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            if (banner.linkUrl.isNotBlank()) {
                                Text(text = "رابط التوجيه: ${banner.linkUrl}", fontSize = 10.sp, color = primaryColor)
                            }
                        }

                        IconButton(onClick = {
                            viewModel.deleteAdBanner(banner.id)
                            showSnackbar.show("تم حذف الإعلان المتحرك المختار عاجلاً.")
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Ad", tint = Color.Red)
                        }
                    }
                }
            }
        }
    }

    showSnackbar.Render()
}

@Composable
fun AdminAccountsView(viewModel: AppViewModel, primaryColor: Color) {
    val list by viewModel.filteredCraftsmen.collectAsState()
    val showSnackbar = rememberInternalToast()

    // Setup input fields for quick craft creation
    var createName by remember { mutableStateOf("") }
    var createProfession by remember { mutableStateOf("") }
    var createBio by remember { mutableStateOf("") }
    var createPhone by remember { mutableStateOf("") }
    val professions by viewModel.allProfessions.collectAsState()

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text("👥 الحسابات والترخيص (إدارة الحرفيين)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("منح شارات التوثيق الزرقاء (✓) يدوياً أو حظر الحسابات المسيئة فوراً عند الضرورة.", fontSize = 11.sp, color = Color.Gray)
        }

        // Quick Registration Form for Test
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F9FB)), border = BorderStroke(1.dp, Color.LightGray.copy(0.5f))) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("🔨 تسجيل سريع لحرفي جديد كأدمن", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = primaryColor)
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedTextField(
                        value = createName,
                        onValueChange = { createName = it },
                        label = { Text("الاسم الكامل للحرفي", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("اختر مهنة الحرفي الموظف*", fontSize = 10.sp, color = Color.Gray)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(professions) { prof ->
                            val active = createProfession == prof.name
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (active) primaryColor else Color.LightGray.copy(0.3f),
                                modifier = Modifier.clickable { createProfession = prof.name }
                            ) {
                                Text(prof.name, fontSize = 9.sp, color = if (active) Color.White else Color.Black, modifier = Modifier.padding(6.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = createPhone,
                        onValueChange = { createPhone = it },
                        label = { Text("رقم هاتفه المباشر", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = createBio,
                        onValueChange = { createBio = it },
                        label = { Text("النبذة التعريفية للحرفي وسيرته", fontSize = 11.sp) },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (createName.isBlank() || createProfession.isBlank() || createPhone.isBlank() || createBio.isBlank()) {
                                showSnackbar.show("الرجاء توفير كافة التفاصيل!")
                            } else {
                                val newId = (100..9999).random()
                                viewModel.saveCraftsmanProfile(newId, createName, createBio, createPhone, createProfession, "avatar_new")
                                showSnackbar.show("تم إثبات وتسجيل الحساب الحرفي الجديد على الشبكة!")
                                createName = ""
                                createProfession = ""
                                createPhone = ""
                                createBio = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("إنشاء وإيداع حساب الحرفي فوراً", color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        }

        // Listing with Ban & Verify Actions
        items(list) { craftsman ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color.LightGray.copy(0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = craftsman.name, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            if (craftsman.isVerified) {
                                Icon(Icons.Default.Check, contentDescription = "Verified Badge", tint = Color(0xFF00C853))
                            }
                        }
                        Text(text = "${craftsman.profession} • هاتف: ${craftsman.phone}", fontSize = 11.sp, color = Color.Gray)
                        if (craftsman.isBlocked) {
                            Text(text = "🚨 حالة الحساب: محظور عن الظهور وتلقي الأعمال", fontSize = 10.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                        } else {
                            Text(text = "✓ حالة الحساب: نشط ويظهر لجميع الزوار عادياً", fontSize = 10.sp, color = Color(0xFF00C853))
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        // Toggle verification (شارة ✓)
                        IconButton(onClick = {
                            viewModel.toggleVerifyCraftsman(craftsman.id)
                            val status = if (!craftsman.isVerified) "منح شارة التوثيق" else "سحب شارة التوثيق"
                            showSnackbar.show("تم $status للحرفي (${craftsman.name}) بنجاح.")
                        }) {
                            Icon(
                                imageVector = if (craftsman.isVerified) Icons.Default.CheckCircle else Icons.Default.Check,
                                contentDescription = "Verify action",
                                tint = if (craftsman.isVerified) Color(0xFF00C853) else Color.LightGray
                            )
                        }

                        // Block toggler (حظر الحرفي من العرض)
                        IconButton(onClick = {
                            viewModel.blockCraftsman(craftsman.id, !craftsman.isBlocked)
                            val act = if (!craftsman.isBlocked) "حظر" else "إلغاء حظر"
                            showSnackbar.show("تم $act الحرفي المختار بالكامل عن الخدمة.")
                        }) {
                            Icon(
                                imageVector = if (craftsman.isBlocked) Icons.Default.Lock else Icons.Default.CheckCircle,
                                contentDescription = "Block action",
                                tint = if (craftsman.isBlocked) Color.Red else Color(0xFFFFA500)
                            )
                        }

                        // Hard delete from DB
                        IconButton(onClick = {
                            viewModel.deleteCraftsman(craftsman.id)
                            showSnackbar.show("تم تهجير وإزالة حساب الحرفي نهائياً من النظام!")
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Purge account", tint = Color.Red)
                        }
                    }
                }
            }
        }
    }

    showSnackbar.Render()
}

@Composable
fun AdminReviewsModerationView(viewModel: AppViewModel, primaryColor: Color) {
    val reviews by viewModel.allReviews.collectAsState()
    val showSnackbar = rememberInternalToast()
    val craftsmenList by viewModel.filteredCraftsmen.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("💬 نظام الرقابة على التقييمات والتعليقات الإجبارية", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text("للإدارة صلاحية المراجعة الفورية وحذف أي تعليق مسيء لضمان المصداقية.", fontSize = 11.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(10.dp))

        if (reviews.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("سجل المراجعات خالي تماماً من التعليقات.", fontSize = 12.sp, color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(reviews) { review ->
                    val relatedCraftsman = craftsmenList.firstOrNull { it.id == review.craftsmanId }
                    
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color.LightGray.copy(0.4f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    Text(
                                        text = "الزبون: ${review.customerName}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black
                                    )
                                    Text(
                                        text = "المستفيد (الحرفي): ${relatedCraftsman?.name ?: "غير معروف (رقم ${review.craftsmanId})"}",
                                        fontSize = 10.sp,
                                        color = primaryColor
                                    )
                                }
                                
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    for (star in 1..5) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = null,
                                            tint = if (star <= review.rating) Color(0xFFFFB300) else Color.LightGray,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            
                            Text(
                                text = "محتوى التعليق: \"${review.comment}\"",
                                fontSize = 12.sp,
                                color = Color.DarkGray,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = review.timestamp.toFormattedArabicDate(),
                                    fontSize = 8.sp,
                                    color = Color.Gray
                                )

                                Button(
                                    onClick = {
                                        viewModel.deleteReview(review.id, review.craftsmanId)
                                        showSnackbar.show("🚨 تم حذف التعليق المختار بنجاح عاجلاً وتعديل متوسط تقييم الحرفي!")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete comment", tint = Color.White, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("حذف التعليق المسيء", fontSize = 10.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    showSnackbar.Render()
}

@Composable
fun AboutScreen(primaryColor: Color) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.widthIn(max = 400.dp)
        ) {
            PalmLogo(modifier = Modifier.size(120.dp), color = primaryColor)
            
            Text(
                text = "تطبيق حرفيي العراق",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = primaryColor
            )

            Text(
                text = "منصة مجتمعية تفاعلية لدعم وتنمية مهارات الكوادر الحرفية في دجلة والفرات وكافة ربوع العراق الحبيب. التطبيق يربط بين الباحث عن الصيانة وذوي الخبرة في أمان تام ومصداقية تامة، وهو مجاني وغير ربحي ١٠٠٪.",
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp,
                color = Color.DarkGray
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = primaryColor.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "📜 شروط الملكية الفكرية",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "جميع الحقوق محفوظة لـ حسين الدخيل",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "أي ممارسة للنسخ أو التطويع من غير رخصة تؤول للمساءلة القانونية والمجتمعية.",
                        fontSize = 10.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Footer of license
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Text(
                    text = "©",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                Text(
                    text = "جميع الحقوق محفوظة لـ حسين الدخيل",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.DarkGray
                )
            }
        }
    }
}

// Custom simple client-side toast controller to show success alerts instantly as simple interactive snackbars
class InternalToastController {
    private var dismissHandler: (() -> Unit)? = null
    val toastMessage = mutableStateOf<String?>(null)
    
    fun show(msg: String) {
        toastMessage.value = msg
    }

    fun dismiss() {
        toastMessage.value = null
    }

    @Composable
    fun Render() {
        val msg = toastMessage.value
        if (msg != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 90.dp, start = 16.dp, end = 16.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF333333)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = msg,
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إغلاق",
                            color = Color(0xFFFFB300),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable { dismiss() }
                                .padding(4.dp)
                        )
                    }
                }
            }
            
            // Auto disappear timer
            LaunchedEffect(msg) {
                kotlinx.coroutines.delay(4000)
                dismiss()
            }
        }
    }
}

@Composable
fun rememberInternalToast(): InternalToastController {
    return remember { InternalToastController() }
}

@Composable
fun AdminFirebaseSyncView(viewModel: AppViewModel, primaryColor: Color) {
    val craftsmen by viewModel.filteredCraftsmen.collectAsState()
    val reviews by viewModel.allReviews.collectAsState()
    val professions by viewModel.allProfessions.collectAsState()
    val firebaseConfig by FirebaseService.firebaseConfigState.collectAsState()

    var apiKeyInput by remember { mutableStateOf("") }
    var projectIdInput by remember { mutableStateOf("") }
    var applicationIdInput by remember { mutableStateOf("") }
    
    // Auth Creation inputs
    var authPhoneInput by remember { mutableStateOf("") }
    var isCraftsmanAuth by remember { mutableStateOf(true) }

    val showSnackbar = rememberInternalToast()

    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            showSnackbar.show("✅ تم تفعيل صلاحية الإشعارات الفورية بنجاح!")
        } else {
            showSnackbar.show("⚠️ يرجى تفعيل صلاحية الإشعارات من إعدادات الهاتف لتتمكن من استلام التنبيهات.")
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "🔥 لوحة ربط ومزامنة Firebase السحابية",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "تهيئة وتفعيل خدمات Firebase Firestore و Authentication وقواعد ترحيل البيانات السحابية بالكامل.",
                fontSize = 11.sp,
                color = Color.Gray
            )
        }

        // Firebase Status Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = if (FirebaseService.isInitialized) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)),
                border = BorderStroke(1.dp, if (FirebaseService.isInitialized) Color(0xFF81C784) else Color(0xFFFFB74D))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "📡 حالة الاتصال بـ Firebase",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (FirebaseService.isInitialized) Color(0xFF2E7D32) else Color(0xFFE65100)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = firebaseConfig,
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }
            }
        }

        // Dynamic Initialization Form
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "⚙️ تهيئة وإعدادات الاتصال اليدوي (بكسل الويب/الأندرويد)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Text(
                        text = "أدخل مفاتيح مشروعك في Firebase للربط الفوري وتشغيل التوثيق وقاعدة البيانات.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it },
                        label = { Text("API Key (مفتاح واجهة برمجة التطبيقات)", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = projectIdInput,
                        onValueChange = { projectIdInput = it },
                        label = { Text("Project ID (معرف المشروع السحابي)", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = applicationIdInput,
                        onValueChange = { applicationIdInput = it },
                        label = { Text("App ID / Mobile ID (معرف التطبيق)", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (apiKeyInput.isBlank() || projectIdInput.isBlank() || applicationIdInput.isBlank()) {
                                showSnackbar.show("❌ الرجاء إدخال جميع الحقول للتهيئة الديناميكية.")
                            } else {
                                val success = FirebaseService.initializeDynamically(
                                    viewModel.getApplication(),
                                    apiKeyInput,
                                    projectIdInput,
                                    applicationIdInput
                                )
                                if (success) {
                                    showSnackbar.show("✅ تم الاتصال بمشروعك في Firebase بنجاح!")
                                } else {
                                    showSnackbar.show("❌ تعذر الاستجابة مع Firebase، تأكد من صحة المفاتيح.")
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ربط وتفعيل مع فيربيس الآن", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        // Firestore Synchronizer Box
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🗄️ مزامنة قاعدة البيانات (Firestore Cloud Bucket)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Text(
                        text = "تصدر هذه الأداة كافة المهن، التقييمات، والحرفيين المسجلين في التطبيق وتعمل على مزامنتها مع Firestore بكبسة زر.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("الحرفيين", fontSize = 10.sp, color = Color.Gray)
                                Text("${craftsmen.size}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = primaryColor)
                            }
                        }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("المهن", fontSize = 10.sp, color = Color.Gray)
                                Text("${professions.size}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = primaryColor)
                            }
                        }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("التقييمات", fontSize = 10.sp, color = Color.Gray)
                                Text("${reviews.size}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = primaryColor)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            FirebaseService.syncDataToFirestore(craftsmen, reviews, professions) { success, msg ->
                                showSnackbar.show(msg)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("مزامنة ومهاجرة قاعدة البيانات مع Firestore ☁️", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        // Firebase Auth user setup / simulation tab
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🔐 توثيق وتسجيل الحسابات عبر Firebase Auth",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Text(
                        text = "تسجيل هوية الحرفيين أو العملاء برقم الهاتف من خلال تفعيل نظام Auth للأمان والمصداقية العالية.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = authPhoneInput,
                        onValueChange = { authPhoneInput = it },
                        label = { Text("رقم هاتفي للحساب المعني (مثال: 0770xxxxxxx)", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = isCraftsmanAuth,
                                onClick = { isCraftsmanAuth = true }
                            )
                            Text("حرفي جديد", fontSize = 11.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = !isCraftsmanAuth,
                                onClick = { isCraftsmanAuth = false }
                            )
                            Text("عميل زبون", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (authPhoneInput.length < 8) {
                                showSnackbar.show("❌ يرجى إدخال رقم هاتف عراقي صالح وصحيح.")
                            } else {
                                FirebaseService.createFirebaseUser(authPhoneInput, isCraftsmanAuth) { success, msg ->
                                    showSnackbar.show(msg)
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("توثيق وتسجيل المشترك في Firebase Auth ✔️", color = Color.DarkGray, fontSize = 12.sp)
                    }
                }
            }
        }

        // 🔔 Push Notifications Simulation card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE0E0E0))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🔔 نظام إدارة وإرسال التنبيهات (Push Notifications Console)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Text(
                        text = "يتيح هذا الكونسول فحص واختبار قنوات نظام الإشعارات الفورية لتنبيه الحرفيين والعملاء فوراً بالرسائل والآراء والتقييمات الجديدة.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (android.os.Build.VERSION.SDK_INT >= 33) {
                                permissionLauncher.launch("android.permission.POST_NOTIFICATIONS")
                            } else {
                                showSnackbar.show("✅ تصريح الإشعارات مفعّل تلقائياً في هذا الإصدار.")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF455A64)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("طلب تصريح إذن الإشعارات من الهاتف (Permission) 🔑", color = Color.White, fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                NotificationHelper.showSystemNotification(
                                    context = viewModel.getApplication(),
                                    title = "💬 تنبيه: رسالة جديدة من زبون",
                                    message = "أهلاً أستاذ، عندي تصليح بوري ماء مكسور بالحمّام، تكدر تجيني اليوم؟",
                                    isChat = true
                                )
                                showSnackbar.show("🔔 تم إرسال إشعار رسالة تجريبي إلى شريط الهاتف!")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("إرسال إشعار رسالة 💬", color = Color.White, fontSize = 10.sp)
                        }

                        Button(
                            onClick = {
                                NotificationHelper.showSystemNotification(
                                    context = viewModel.getApplication(),
                                    title = "⭐ تنبيه: تقييم جديد ممتاز!",
                                    message = "قام زبون بتقييمك بـ 5 نجوم: 'عاش ايدك شغل سريع وممتاز وأنصح بتعامله.'",
                                    isChat = false
                                )
                                showSnackbar.show("🔔 تم إرسال إشعار تقييم تجريبي إلى الهاتف!")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("إرسال إشعار تقييم ⭐", color = Color.White, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
    showSnackbar.Render()
}
