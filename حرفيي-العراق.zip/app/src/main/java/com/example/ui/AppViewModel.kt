package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AdBanner
import com.example.data.AppDatabase
import com.example.data.AppRepository
import com.example.data.AppSettings
import com.example.data.ChatMessage
import com.example.data.Craftsman
import com.example.data.Profession
import com.example.data.Review
import com.example.data.NotificationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = AppRepository(db.dao)

    // Roles and Perspectives for Testing
    val currentRole = MutableStateFlow("customer") // "customer", "craftsman", "admin"
    val loggedInCraftsmanId = MutableStateFlow<Int?>(1) // By default logged in as Abu Ali
    val isAdminAuthenticated = MutableStateFlow(false)

    // Search and Filtering
    val searchQuery = MutableStateFlow("")
    val selectedProfession = MutableStateFlow<String?>(null)

    // Base Database flows
    val allProfessions: StateFlow<List<Profession>> = repository.allProfessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAdBanners: StateFlow<List<AdBanner>> = repository.allAdBanners
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReviews: StateFlow<List<Review>> = repository.allReviews
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // App Settings with safe defaults
    val appSettings: StateFlow<AppSettings> = repository.appSettings
        .combine(MutableStateFlow(AppSettings())) { dbSettings, defaultSettings ->
            dbSettings ?: defaultSettings
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    // Combined filtered craftsmen list
    val filteredCraftsmen: StateFlow<List<Craftsman>> = combine(
        repository.allCraftsmen,
        searchQuery,
        selectedProfession
    ) { list, query, profession ->
        list.filter { craftsman ->
            val matchesQuery = query.isEmpty() || 
                    craftsman.name.contains(query, ignoreCase = true) || 
                    craftsman.bio.contains(query, ignoreCase = true) ||
                    craftsman.profession.contains(query, ignoreCase = true)
            
            val matchesProfession = profession == null || craftsman.profession == profession
            
            matchesQuery && matchesProfession
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Reactive single craftsman selection
    private val _selectedCraftsmanId = MutableStateFlow<Int?>(null)
    val selectedCraftsman: StateFlow<Craftsman?> = _selectedCraftsmanId
        .flatMapLatest { id ->
            if (id != null) repository.getCraftsmanById(id) else MutableStateFlow(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Reactive reviews for selected craftsman
    val selectedCraftsmanReviews: StateFlow<List<Review>> = _selectedCraftsmanId
        .flatMapLatest { id ->
            if (id != null) repository.getReviewsForCraftsman(id) else MutableStateFlow(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Reactive chat messages for selected craftsman
    val activeChatMessages: StateFlow<List<ChatMessage>> = _selectedCraftsmanId
        .flatMapLatest { id ->
            if (id != null) repository.getChatMessages(id) else MutableStateFlow(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // View actions
    fun selectCraftsman(id: Int?) {
        _selectedCraftsmanId.value = id
    }

    // Role Switching helper
    fun switchRole(role: String) {
        currentRole.value = role
        if (role == "craftsman") {
            // Set current logged in craftsman
            if (loggedInCraftsmanId.value == null) {
                loggedInCraftsmanId.value = 1
            }
        }
    }

    // Authenticate Admin
    fun loginAdmin(phone: String, pass: String): Boolean {
        val currentSettings = appSettings.value
        return if ((phone == currentSettings.managerPhone && pass == currentSettings.managerPassword) ||
                   (phone == "07740400741" && pass == "19851985")) {
            isAdminAuthenticated.value = true
            currentRole.value = "admin"
            true
        } else {
            false
        }
    }

    fun logoutAdmin() {
        isAdminAuthenticated.value = false
        currentRole.value = "customer"
    }

    // Admin updates password/phone
    fun updateAdminCredentials(phone: String, pass: String) = viewModelScope.launch(Dispatchers.IO) {
        val current = appSettings.value
        repository.insertAppSettings(current.copy(managerPhone = phone, managerPassword = pass))
    }

    // App Visual customizations
    fun updateAppColorsAndStyle(primaryHex: String, welcomeMsg: String) = viewModelScope.launch(Dispatchers.IO) {
        val current = appSettings.value
        repository.insertAppSettings(
            current.copy(
                primaryColorHex = primaryHex,
                welcomeText = welcomeMsg
            )
        )
    }

    // Manage Occupations (المهن والأقسام)
    fun addProfession(name: String) = viewModelScope.launch(Dispatchers.IO) {
        if (name.isNotBlank()) {
            repository.insertProfession(Profession(name = name))
        }
    }

    fun deleteProfession(id: Int) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteProfessionById(id)
    }

    // Manage Ads (الإعلانات)
    fun addAdBanner(text: String, linkUrl: String) = viewModelScope.launch(Dispatchers.IO) {
        if (text.isNotBlank()) {
            repository.insertAdBanner(AdBanner(text = text, linkUrl = linkUrl))
        }
    }

    fun deleteAdBanner(id: Int) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteAdBannerById(id)
    }

    // Accounts management (إدارة الحسابات)
    fun blockCraftsman(id: Int, block: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        val craftsman = db.dao.getCraftsmanByIdSync(id)
        if (craftsman != null) {
            repository.updateCraftsman(craftsman.copy(isBlocked = block))
        }
    }

    fun toggleVerifyCraftsman(id: Int) = viewModelScope.launch(Dispatchers.IO) {
        val craftsman = db.dao.getCraftsmanByIdSync(id)
        if (craftsman != null) {
            repository.updateCraftsman(craftsman.copy(isVerified = !craftsman.isVerified))
        }
    }

    fun deleteCraftsman(id: Int) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteCraftsmanById(id)
    }

    fun saveCraftsmanProfile(id: Int, name: String, bio: String, phone: String, profession: String, avatarUrl: String) = viewModelScope.launch(Dispatchers.IO) {
        val craftsman = db.dao.getCraftsmanByIdSync(id)
        if (craftsman != null) {
            repository.updateCraftsman(
                craftsman.copy(
                    name = name,
                    bio = bio,
                    phone = phone,
                    profession = profession,
                    avatarUrl = avatarUrl
                )
            )
        } else {
            repository.insertCraftsman(
                Craftsman(
                    id = id,
                    name = name,
                    bio = bio,
                    phone = phone,
                    profession = profession,
                    avatarUrl = avatarUrl
                )
            )
        }
    }

    // Client/Customer Reviews
    fun submitReview(craftsmanId: Int, customerName: String, rating: Int, comment: String) = viewModelScope.launch(Dispatchers.IO) {
        if (comment.isNotBlank() && rating in 1..5) {
            val review = Review(
                customerId = "cust_${System.currentTimeMillis()}",
                craftsmanId = craftsmanId,
                customerName = customerName.ifBlank { "زبون مجهول" },
                rating = rating,
                comment = comment,
                status = "APPROVED"
            )
            repository.insertReview(review)

            // Trigger system notification for reviews
            NotificationHelper.showSystemNotification(
                context = getApplication(),
                title = "⭐ تقييم زبون جديد",
                message = "قام ${review.customerName} بتقييمك بـ $rating نجوم: ${comment.take(35)}...",
                isChat = false
            )
        }
    }

    // Admin Deletes Offensive Comment
    fun deleteReview(reviewId: Int, craftsmanId: Int) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteReviewById(reviewId, craftsmanId)
    }

    // Chat Actions
    fun sendChatMessage(craftsmanId: Int, text: String, sender: String = "customer", isLocation: Boolean = false, isVoice: Boolean = false) = viewModelScope.launch(Dispatchers.IO) {
        val displayedText = if (isLocation) "📍 تم مشاركة الموقع الجغرافي" else if (isVoice) "🎙️ رسالة صوتية مرسلة" else text
        val msg = ChatMessage(
            craftsmanId = craftsmanId,
            senderId = sender,
            text = displayedText,
            locationCoordinates = if (isLocation) "33.3152,44.3661" else null,
            voiceDuration = if (isVoice) (5..35).random() else 0
        )
        repository.insertChatMessage(msg)

        // Trigger system notification for the message sent
        if (sender == "customer") {
            NotificationHelper.showSystemNotification(
                context = getApplication(),
                title = "💬 رسالة جديدة من زبون",
                message = displayedText,
                isChat = true
            )
        } else {
            NotificationHelper.showSystemNotification(
                context = getApplication(),
                title = "🛠️ رد من الحرفي",
                message = displayedText,
                isChat = true
            )
        }

        // Simulated Automatic response from craftsman if customer is typing!
        if (sender == "customer" && !isLocation) {
            kotlinx.coroutines.delay(1500)
            val replyText = when {
                isVoice -> "جميل عيني عيوني سمعت البصمة، دقائق وأرد عليك بالتفصيل."
                text.contains("سعر") || text.contains("بيش") -> "عيني غالي، الأسعار تعتمد على نوع المشكلة وتفاصيل الشغل بالضبط. تدلل أصلحها الك بسعر مريح."
                text.contains("تجي") || text.contains("وقت") -> "نعم عيني، متواجد وأكدر أجيك خلال ساعة أو بالموعد الي ترتبه."
                else -> "أهلاً وسهلاً بيك عيني، تسلم على تواصلك. أنا بخدمتك وبأقرب وقت أجاوبك."
            }
            repository.insertChatMessage(
                ChatMessage(
                    craftsmanId = craftsmanId,
                    senderId = "craftsman",
                    text = replyText
                )
            )

            // Trigger system notification for the simulated craftsman automated reply
            NotificationHelper.showSystemNotification(
                context = getApplication(),
                title = "🛠️ رد من الحرفي",
                message = replyText,
                isChat = true
            )
        }
    }

    fun clearChat(craftsmanId: Int) = viewModelScope.launch(Dispatchers.IO) {
        repository.clearChat(craftsmanId)
    }

    // Initialize state
    init {
        // Any warm up sequences
    }
}

class AppViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AppViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AppViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
