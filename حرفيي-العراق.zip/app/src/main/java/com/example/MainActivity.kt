package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.FirebaseService
import com.example.data.NotificationHelper
import com.example.ui.AppUi
import com.example.ui.AppViewModel
import com.example.ui.AppViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Safety initialize Firebase (supports both automatic and dynamic fallback)
        FirebaseService.safetyInitialize(applicationContext)
        
        // Initialize Notification Channels
        NotificationHelper.createNotificationChannels(applicationContext)
        
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Initialize the app viewModel with Application context safely
                val appViewModel: AppViewModel = viewModel(
                    factory = AppViewModelFactory(application)
                )
                
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppUi(viewModel = appViewModel)
                }
            }
        }
    }
}

